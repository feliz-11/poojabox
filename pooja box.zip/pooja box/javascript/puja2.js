var myIndey2 = 0;
carousel1();

function carousel1() {
  var i;
  var y = document.getElementsByClassName("mySlides2");
  for (i = 0; i < y.length; i++) {
    y[i].style.display = "none";  
  }
  myIndey2++;
  if (myIndey2 > y.length) {myIndey2 = 1}    
  y[myIndey2-1].style.display = "block";  
  setTimeout(carousel1, 400); // Change image every 2 seconds
}